<template>
  <YesNo />
</template>

<script>
import YesNo from '../components/YesNoComponent.vue'

export default {
  name: 'App',
  components: {
      YesNo
  }
}
</script>

<style>

</style>
